<?php

	// Constants
	define("TITLE", "Chad wants your mom.");

	// Variables
	$myName = 'Sam Ringleman';

	// Arrays
	$ageGroup = ["child", "teenager", "adult"];
	$handlebar = [
		'name' => "Handlebar",
		'color' => "Black"
	];
	$fuManchu = [
		'name' => "Fu Manchu",
		'color' => "Brown"
	];
	$salvadorDali = [
		'name' => "Salvador Dali",
		'color' => "Blonde",
	];
	$gentleman = [
		[
			'firstName' => "Carter",
			'country' => "Canada"
		],
		[
			'firstName' => "Rodrigo",
			'country' => "Uruguay"
		],
		[
			'firstName' => "Giovanni",
			'country' => "Italy"
		]
	];
?>

<!DOCTYPE html>
<html>
	<head>
		<title>Get Your Hands Dirty: <?php echo TITLE; ?></title>
		<link href="/assets/styles.css" rel="stylesheet">
		<script type="text/javascript" src="/assets/syntaxhighlighter/scripts/shCore.js"></script>
		<script type="text/javascript" src="/assets/syntaxhighlighter/scripts/shBrushPhp.js"></script>
		<link type="text/css" rel="stylesheet" href="/assets/syntaxhighlighter/styles/shCoreDefault.css"/>
		<script type="text/javascript">SyntaxHighlighter.all();</script>
	</head>
	<body>
		<div class="wrapper">
			<a href="/" title="Back to directory" id="logo">
				<img src="/assets/img/logo.png" alt="PHP">
			</a>

			<h1>Get Your Hands Dirty: <small><!-- TITLE --></small></h1>
			<hr>

			<h2>Your Example</h2>

			<div class="sandbox">

				<h3><?php echo $gentleman[0][firstName]; ?> from <?php echo $gentleman[0][country]; ?></h3>
				<p><?php echo $gentleman[0][firstName]; ?> is quite the <?php echo $ageGroup[2]; ?>! He sports a solid <?php echo $handlebar[name]; ?> moustache that is <?php echo $handlebar[color]; ?> in color.</p>

				<h3><?php echo $gentleman[1][firstName]; ?> from <?php echo $gentleman[1][country]; ?></h3>
				<p><?php echo $gentleman[1][firstName]; ?> is a rather dapper <?php echo $ageGroup[1]; ?>! He sports a solid <?php echo $fuManchu[name]; ?> moustache that is <?php echo $fuManchu[color]; ?> in color.</p>

				<h3><?php echo $gentleman[2][firstName]; ?> from <?php echo $gentleman[2][country]; ?></h3>
				<p><?php echo $gentleman[2][firstName]; ?> might seem to young for a 'stache because he is a  <?php echo $ageGroup[0]; ?>! He sports a solid <?php echo $salvadorDali[name]; ?> moustache that is <?php echo $salvadorDali[color]; ?> in color.</p>


			</div><!-- end sandbox -->

			<a href="index.php" class="button">Back to the final example</a>

			<div class="navs cf">
				<a href="" class="button prev">Previous Lecture</a>
				<a href="" class="button next">Next Lecture</a>
			</div><!-- end navs -->

			<hr>

			<small>&copy;<?php echo date("Y"); ?> - <?php echo $myName; ?></small>
		</div><!-- end wrapper -->


	</body>
</html>
