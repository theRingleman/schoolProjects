<?php

	// Define a Constant
	define("TITLE", "Chad Bradley is a total chode.");

	// Your Variables
	$myName = "Sam";
	$favColor = "Suck it chode";
	$birthYear = "1989";

	/*
		When using the date() method, PHP has to know the timezone where the server resides,
		in order to output the correct hour and date for that geographical location.
		The date_default_timezone_set() method takes a string that locates the server.
		The list of supported timezones can be found at http://php.net/manual/en/timezones.php
	*/
	date_default_timezone_set('America/Denver');

	$today = date('F j, Y');
	$thisYear = date("Y");

	/*
	Use PHP to calculate the difference
	between your birth year and this year
	to show your age dynamically
	*/
	$myAge		= ($thisYear - $birthYear);

?>

<!DOCTYPE html>
<html>
	<head>
		<title>Get Your Hands Dirty: <?php echo TITLE; ?></title>
		<link href="../assets/styles.css" rel="stylesheet">
	</head>
	<body>
		<div class="wrapper">
			<a href="/" title="Back to directory" id="logo">
				<img src="../assets/img/logo.png" alt="PHP">
			</a>

			<h1>Get Your Hands Dirty: <small><?php echo TITLE; ?></small></h1>
			<hr>

			<h2>Final Example</h2>
			<p>Make sure to view the source code in your editor!</p>

			<div class="sandbox">
				<h3>Today's Date:</h3>
				<p><?php echo $today; ?></p>

				<h3>My Name:</h3>
				<p><?php echo $myName; ?></p>

				<h3>My Favourite Colour:</h3>
				<p><?php echo $favColor; ?></p>

				<h3>My Age:</h3>
				<p><?php echo $myAge; ?></p>
			</div><!-- end sandbox -->

			<a href="practice.php" class="button">Check out your example</a>

			<div class="navs cf">
				<a href="/04_DefiningConstants" class="button prev">Previous Lecture</a>
				<a href="/06_Arrays" class="button next">Next Lecture</a>
			</div><!-- end navs -->

			<hr>

			<small>&copy;<?php echo $thisYear; ?> <a href="http://bradhussey.ca/"><?php echo $myName; ?></a></small>
		</div><!-- end wrapper -->

		<div class="copyright-info">
			<?php include('../assets/includes/copyright.php'); ?>
		</div><!-- end copyright-info -->
	</body>
</html>
